import mongoose from 'mongoose';
import { config } from './env.js';

export const connectDB = async () => {
  try {
    const conn = await mongoose.connect(config.mongoUri);
    console.log(
      `[DB] Connected to "${conn.connection.name}" in [${config.env.toUpperCase()}] mode`
    );
  } catch (error) {
    console.error(`[DB] Connection failed (${config.env}):`, error.message);
    process.exit(1);
  }
};

export const disconnectDB = async () => {
  await mongoose.disconnect();
  console.log('[DB] Disconnected');
};