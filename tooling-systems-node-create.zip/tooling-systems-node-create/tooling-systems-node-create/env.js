import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';

const VALID_ENVS = ['staging', 'preprod', 'prod'];
const currentEnv = process.env.NODE_ENV || 'staging';

if (!VALID_ENVS.includes(currentEnv)) {
  throw new Error(`Invalid NODE_ENV "${currentEnv}". Must be one of: ${VALID_ENVS.join(', ')}`);
}

const envPath = path.resolve(process.cwd(), `.env.${currentEnv}`);

if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath });
} else {
  console.warn(`[Config] Warning: ${envPath} not found. Using system environment variables.`);
}

if (!process.env.MONGO_URI) {
  throw new Error(`[Config] Missing MONGO_URI for environment: ${currentEnv}`);
}

export const config = Object.freeze({
  env: currentEnv,
  appName: process.env.APP_NAME || 'NodeMongoApp',
  mongoUri: process.env.MONGO_URI,
});